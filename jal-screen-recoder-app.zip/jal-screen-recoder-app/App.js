import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TouchableOpacity, 
  ScrollView, 
  Switch, 
  Dimensions,
  SafeAreaView,
  Alert
} from 'react-native';

const { width, height } = Dimensions.get('window');

export default function App() {
  // Theme State
  const [isDarkMode, setIsDarkMode] = useState(true);
  
  // App Navigation Slide State (1: Settings/Record, 2: Gallery, 3: Editor)
  const [currentSlide, setCurrentSlide] = useState(1);

  // Recording Settings State
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [fps, setFps] = useState(120); // Capped at S23 FE Max 120Hz
  const [bitrate, setBitrate] = useState(100); // Mbps
  const [resolution, setResolution] = useState('4K');
  const [codec, setCodec] = useState('H.265 (HEVC)');
  const [audioSource, setAudioSource] = useState('System + Mic');

  // Permissions State Mock
  const [hasPermissions, setHasPermissions] = useState(false);

  const requestPermissions = () => {
    // In a real app, you would call Audio and MediaProjection APIs here
    Alert.alert(
      "Permissions Requested",
      "|~_~|J/\\L requires Mic, Audio, and Media Storage access. No location tracking used.",
      [{ text: "Grant", onPress: () => setHasPermissions(true) }]
    );
  };

  // Glassmorphic Theme Styles based on Light/Dark Mode
  const theme = {
    background: isDarkMode ? '#0f0f14' : '#f0f2f5',
    glass: isDarkMode ? 'rgba(255, 255, 255, 0.07)' : 'rgba(0, 0, 0, 0.05)',
    glassBorder: isDarkMode ? 'rgba(255, 255, 255, 0.15)' : 'rgba(0, 0, 0, 0.1)',
    text: isDarkMode ? '#ffffff' : '#1c1c1e',
    subText: isDarkMode ? '#a1a1aa' : '#636366',
    accent: '#007AFF', // iOS Blue
    recordRed: '#FF3B30'
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      {/* HEADER TABS & THEME TOGGLE */}
      <View style={styles.header}>
        <Text style={[styles.logo, { color: theme.text }]}>|~_~|J/\L</Text>
        <View style={styles.themeRow}>
          <Text style={{ color: theme.subText, marginRight: 8 }}>{isDarkMode ? "Dark" : "Light"}</Text>
          <Switch 
            value={isDarkMode} 
            onValueChange={(val) => setIsDarkMode(val)}
            trackColor={{ false: '#767577', true: theme.accent }}
          />
        </View>
      </View>

      {/* THREE SLIDES MAIN WORKSPACE */}
      <View style={styles.workspace}>
        
        {/* SLIDE 1: RECORD & SETTINGS */}
        {currentSlide === 1 && (
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Main Glass Record Card */}
            <View style={[styles.glassCard, { backgroundColor: theme.glass, borderColor: theme.glassBorder }]}>
              <Text style={[styles.cardTitle, { color: theme.text }]}>Control Panel</Text>
              
              <View style={styles.recordButtonContainer}>
                {!isRecording ? (
                  <TouchableOpacity 
                    style={[styles.bigRecordButton, { backgroundColor: theme.recordRed }]}
                    onPress={() => {
                      if(!hasPermissions) { requestPermissions(); return; }
                      setIsRecording(true);
                    }}
                  >
                    <Text style={styles.buttonTextInner}>START 4K</Text>
                  </TouchableOpacity>
                ) : (
                  <View style={styles.activeControlsRow}>
                    <TouchableOpacity 
                      style={[styles.controlButton, { backgroundColor: theme.accent }]}
                      onPress={() => setIsPaused(!isPaused)}
                    >
                      <Text style={styles.buttonTextInner}>{isPaused ? "Resume" : "Pause"}</Text>
                    </TouchableOpacity>
                    
                    <TouchableOpacity 
                      style={[styles.controlButton, { backgroundColor: '#FF9500' }]}
                      onPress={() => Alert.alert("Screenshot", "Captured at 4K resolution!")}
                    >
                      <Text style={styles.buttonTextInner}>Snap</Text>
                    </TouchableOpacity>

                    <TouchableOpacity 
                      style={[styles.controlButton, { backgroundColor: theme.recordRed }]}
                      onPress={() => {
                        setIsRecording(false);
                        setIsPaused(false);
                        Alert.alert("Saved", "Screen capture saved to Slide 2 Gallery.");
                      }}
                    >
                      <Text style={styles.buttonTextInner}>Stop</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
              {isRecording && (
                <Text style={styles.statusText}>
                  ● Recording status: {isPaused ? 'Paused' : 'Active (Low Latency Engine)'}
                </Text>
              )}
            </View>

            {/* Custom Settings Card */}
            <View style={[styles.glassCard, { backgroundColor: theme.glass, borderColor: theme.glassBorder }]}>
              <Text style={[styles.cardTitle, { color: theme.text }]}>Custom Settings</Text>

              {/* Resolution Selector */}
              <Text style={[styles.settingLabel, { color: theme.subText }]}>Resolution</Text>
              <View style={styles.optionRow}>
                {['1080p', '2K', '4K'].map((res) => (
                  <TouchableOpacity 
                    key={res} 
                    style={[styles.selectorButton, resolution === res && {backgroundColor: theme.accent}]}
                    onPress={() => setResolution(res)}
                  >
                    <Text style={{color: resolution === res ? '#fff' : theme.text}}>{res}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Frame Rate Selector */}
              <Text style={[styles.settingLabel, { color: theme.subText }]}>Frame Rate (Max Screen Sync)</Text>
              <View style={styles.optionRow}>
                {[60, 90, 120].map((f) => (
                  <TouchableOpacity 
                    key={f} 
                    style={[styles.selectorButton, fps === f && {backgroundColor: theme.accent}]}
                    onPress={() => setFps(f)}
                  >
                    <Text style={{color: fps === f ? '#fff' : theme.text}}>{f} FPS</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Bitrate Selector */}
              <Text style={[styles.settingLabel, { color: theme.subText }]}>Target Bitrate: {bitrate} Mbps</Text>
              <View style={styles.optionRow}>
                {[20, 100, 250, 500].map((b) => (
                  <TouchableOpacity 
                    key={b} 
                    style={[styles.selectorButton, bitrate === b && {backgroundColor: theme.accent}]}
                    onPress={() => setBitrate(b)}
                  >
                    <Text style={{color: bitrate === b ? '#fff' : theme.text}}>{b}M</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Codecs configuration */}
              <Text style={[styles.settingLabel, { color: theme.subText }]}>Ultra Low Latency Codec</Text>
              <View style={styles.optionRow}>
                {['H.264', 'H.265 (HEVC)', 'VP9 / AV1'].map((c) => (
                  <TouchableOpacity 
                    key={c} 
                    style={[styles.selectorButton, codec === c && {backgroundColor: theme.accent}, {flex: 1}]}
                    onPress={() => setCodec(c)}
                  >
                    <Text style={{color: codec === c ? '#fff' : theme.text, fontSize: 11}}>{c}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Audio Source Options */}
              <Text style={[styles.settingLabel, { color: theme.subText }]}>Audio Capture Layout</Text>
              <View style={styles.optionRow}>
                {['System', 'Mic Only', 'System + Mic'].map((a) => (
                  <TouchableOpacity 
                    key={a} 
                    style={[styles.selectorButton, audioSource === a && {backgroundColor: theme.accent}, {flex: 1}]}
                    onPress={() => setAudioSource(a)}
                  >
                    <Text style={{color: audioSource === a ? '#fff' : theme.text, fontSize: 11}}>{a}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </ScrollView>
        )}

        {/* SLIDE 2: RECORDED GALLERY */}
        {currentSlide === 2 && (
          <View style={styles.slideCenterContainer}>
            <View style={[styles.glassCard, { backgroundColor: theme.glass, borderColor: theme.glassBorder, width: '100%' }]}>
              <Text style={[styles.cardTitle, { color: theme.text }]}>Recorded Clips</Text>
              <Text style={{ color: theme.subText, textAlign: 'center', marginVertical: 40 }}>
                No recordings found. Start capturing in Slide 1 to generate high-bitrate outputs.
              </Text>
            </View>
          </View>
        )}

        {/* SLIDE 3: VIDEO EDITOR INTENT */}
        {currentSlide === 3 && (
          <View style={styles.slideCenterContainer}>
            <View style={[styles.glassCard, { backgroundColor: theme.glass, borderColor: theme.glassBorder, width: '100%' }]}>
              <Text style={[styles.cardTitle, { color: theme.text }]}>Integrated Video Editor</Text>
              <Text style={{ color: theme.subText, marginBottom: 20 }}>
                Active Profile: {resolution} @ {fps}FPS ({codec})
              </Text>
              
              {/* Fake Timeline Tool */}
              <View style={[styles.fakeTimeline, {backgroundColor: isDarkMode ? '#2c2c2e' : '#e5e5ea'}]}>
                <Text style={{color: theme.subText, fontSize: 12}}>[ Video Track Timeline ]</Text>
              </View>

              {/* Editor Buttons */}
              <View style={styles.optionRow}>
                {['Trim', 'Cut', 'Audio Boost', 'Merge'].map((tool) => (
                  <TouchableOpacity key={tool} style={[styles.selectorButton, {backgroundColor: theme.glass, borderColor: theme.glassBorder, flex: 1}]}>
                    <Text style={{color: theme.text, fontSize: 12}}>{tool}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        )}

      </View>

      {/* BOTTOM IPHONE STYLE NAVIGATION TABS */}
      <View style={[styles.navBar, { backgroundColor: theme.glass, borderColor: theme.glassBorder }]}>
        <TouchableOpacity style={styles.navTab} onPress={() => setCurrentSlide(1)}>
          <Text style={[styles.navText, { color: currentSlide === 1 ? theme.accent : theme.subText }]}>🎛 Rec & Setup</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navTab} onPress={() => setCurrentSlide(2)}>
          <Text style={[styles.navText, { color: currentSlide === 2 ? theme.accent : theme.subText }]}>📁 Gallery</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navTab} onPress={() => setCurrentSlide(3)}>
          <Text style={[styles.navText, { color: currentSlide === 3 ? theme.accent : theme.subText }]}>✂ Editor</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 10,
  },
  logo: {
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: 1,
  },
  themeRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  workspace: {
    flex: 1,
    paddingHorizontal: 15,
  },
  glassCard: {
    borderRadius: 24,
    padding: 20,
    marginVertical: 10,
    borderWidth: 1,
    backdropFilter: 'blur(20px)', // Visual representation for web/modern engines
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 15,
  },
  recordButtonContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
  },
  bigRecordButton: {
    width: 110,
    height: 110,
    borderRadius: 55,
    justifyContent: 'center',
    alignItems: 'center',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  buttonTextInner: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
    textAlign: 'center',
  },
  activeControlsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  controlButton: {
    flex: 1,
    height: 50,
    borderRadius: 14,
    marginHorizontal: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusText: {
    color: '#34C759',
    textAlign: 'center',
    marginTop: 15,
    fontWeight: '600',
  },
  settingLabel: {
    fontSize: 13,
    fontWeight: '600',
    marginTop: 15,
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  optionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
  },
  selectorButton: {
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(150,150,150,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 65,
  },
  slideCenterContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  fakeTimeline: {
    height: 80,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderStyle: 'dashed',
    borderWidth: 1,
    borderColor: '#8e8e93',
  },
  navBar: {
    flexDirection: 'row',
    height: 65,
    marginHorizontal: 15,
    marginBottom: 15,
    borderRadius: 25,
    borderWidth: 1,
    overflow: 'hidden',
  },
  navTab: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  navText: {
    fontSize: 13,
    fontWeight: '700',
  },
});
